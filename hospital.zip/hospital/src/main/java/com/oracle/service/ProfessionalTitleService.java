package com.oracle.service;

import com.oracle.pojo.ProfessionalTitle;

import java.util.List;

public interface ProfessionalTitleService {

    List<ProfessionalTitle> AllProfessionalTitleList();
}
